/*
 * @Descripttion: 
 * @version: 
 * @Author: 刘童鞋
 * @Date: 2022-10-17 23:37:55
 * @LastEditors: 刘童鞋
 * @LastEditTime: 2022-10-17 23:37:58
 */
interface ImportMetaEnv {
    VITE_APP_BASE_URL: string
  }